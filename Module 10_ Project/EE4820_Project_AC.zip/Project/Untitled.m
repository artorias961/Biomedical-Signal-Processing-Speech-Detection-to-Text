close all
clear all
nfft = 2^16;
Lwin = 256;
win = window(@hamming,Lwin);
Noverlap = round(Lwin * 0.8);
phonemes_array = [];
phonemesFreqStart = [];
phonemesFreqEnd   = [];
%% -------------------------------------------------------------------
graph = 1;
Letter = "t";
[data, fs] = audioread('TrainingData\t testing testing t sound.m4a');
fc = [400 10000]; Wn = fc/(fs/2);
[b, a] = butter(8,Wn,'bandpass');
data = filtfilt(b,a,data);
[S, F, T] = spectrogram(data, win, Noverlap, nfft, fs);
if (graph == 1)
    figure;
    imagesc(T ,F ,abs(S));
    title(Letter + " signal");
end
T_index_start = find(T >= 1.107);
T_index_end   = find(T >= 1.155);
Stemp = S(:,T_index_start(1):T_index_end(1)); Smax = max(abs(Stemp),[],'all');
temp = S(:,T_index_start(1):T_index_end(1));
temp = abs(temp);
temp = sum(abs(temp),2); temp = temp/Smax; temp = temp./(T_index_end(1) - T_index_start(1));
phonemes_array = [phonemes_array temp];
start = 0;
ends  = 14000;
Freq = find(F>=start & F<=ends);
F_start = Freq(1); 
F_end = Freq(end); 
Stemp = abs(Stemp(F_start:F_end,:));

Stemp = Stemp/Smax;
if (graph == 1)
    figure; 
    imagesc(T(T_index_start(1):T_index_end(1)),F(F_start:F_end) ,abs(Stemp));
    title("zoomed in to letter "+Letter);
end
Stemp = abs(Stemp);
Stemp = sum(abs(Stemp),2);
t_stft = Stemp./(T_index_end(1) - T_index_start(1));
t_Fstart = F_start; phonemesFreqStart = [phonemesFreqStart F_start];
t_Fend   = F_end; phonemesFreqEnd   = [phonemesFreqEnd F_end];
%% -------------------------------------------------------------------